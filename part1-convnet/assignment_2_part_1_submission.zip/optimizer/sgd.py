from ._base_optimizer import _BaseOptimizer
class SGD(_BaseOptimizer):
    def __init__(self, model, learning_rate=1e-4, reg=1e-3, momentum=0.9):
        super().__init__(model, learning_rate, reg)
        self.momentum = momentum

    def update(self, model):
        '''
        Update model weights based on gradients
        :param model: The model to be updated
        :return: None, but the model weights should be updated
        '''
        self.apply_regularization(model)

        for idx, m in enumerate(model.modules):
            if hasattr(m, 'weight'):
                #############################################################################
                # TODO:                                                                     #
                #    1) Momentum updates for weights                                        #
                #############################################################################
                vw = self.grad_tracker[idx]['dw']
                vw = self.momentum * vw - self.learning_rate * m.dw
                m.weight += vw
                self.grad_tracker[idx]['dw'] = vw

                #############################################################################
                #                              END OF YOUR CODE                             #
                #############################################################################
            if hasattr(m, 'bias'):
                #############################################################################
                # TODO:                                                                     #
                #    1) Momentum updates for bias                                           #
                #############################################################################
                vb = self.grad_tracker[idx]['db']
                vb = self.momentum * vb - self.learning_rate * m.db
                m.bias += vb
                self.grad_tracker[idx]['db'] = vb
                #############################################################################
                #                              END OF YOUR CODE                             #
                #############################################################################
